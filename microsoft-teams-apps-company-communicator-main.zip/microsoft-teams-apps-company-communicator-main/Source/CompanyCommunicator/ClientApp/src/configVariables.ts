// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

export const getBaseUrl = (): string => {
  return window.location.origin;
};
